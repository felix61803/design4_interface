import sys
import time

#Définition des classes du modèle de calcul ---------------------------------------------------------------------

""" Modele de la batterie

    Le modèle de la batterie est basée sur son équivalent Thévenin. De l'extérieur, la batterie est une source à deux bornes (+) Vbat (-).
    Le modèle inclue un source idéale (Tension interne; Vint) variant selon le niveau de charge de la batterie et une résistance interne (Rint).
    La tension selon le niveau de charge est déterminé selon une équation du 3ème ordre, prédéterminer pour les batteries au plomb à décharge lente.
    Les coefficients peut être manuellement entrés par l'utilisation de la méthode updateModel(ordre3, ordre2, ordre1, ordre0)
    Notes : 
        Une génératrice est modélisée comme une batterie idéale avec 1 GJ de capacité (fonctionnellement infinie), 
            un courant de recharge maximale à 0A et un courant de décharge maximal de 1MA
        Durant le dimensionnement, l'état de charge initiale est considéré à 100% et 1 GJ de capacité, les autres paramètres sont ceux définis par l'utilisateur

    Schéma de la batterie
            Équation équivalente : Vbat = R*I + Vint

     -----/\/\------
     |    Rint     |
    (+)           (+)
    Vint          Vbat
    (-)           (-)
     |             |
     ---------------

    Initialisation (code dans def __init__):
        Contient tous les paramètres définissant une batterie étant nécessaire pour la simulation
        Un objet du type batterie est crée. Ce objet se souvient de ses paramètres initiaux et de son état actuel.

    Fonctionnement (à chaque pas de la simulation): 

    La méthode powerTransfert(power) est appliquée et effectue les étapes suivantes
        1) Selon la puissance consommée/regénérée et la tension à la batterie, le courant (current) est calculé.
        2) La perte resistive (powerLoss) est calculé et accumulée dans une variable (sumLoss) et ajouté/enlevé de la puissance consommée/régénérée
        3) L'énergie actuellement consommée/régénérée par la batterie est ensuite retirée/ajoutée à l'énergie contenue dans la batterie (energy)
        4) L'état de charge de la batterie (percent), la tension interne (intVoltage) et la tension externe (voltage) sont recalculés
        5) Les signaux de contrôles et la plage d'énergie utilisée durant le cycle sont mis-à-jour

    Paramètres d'entrée
        batType :       Type de batterie. 0 : Plomb à décharge profonde. 1 : LiFePO4. D'autres batteries peuvent être ajoutées en modifiant le code
        V_nominal :     Somme des tensions nominales de la banque de batterie
                            Tension nominale : selon le fabricant (p.ex, une batterie d'auto normale est affichée comme une 12V)
        capacity :      Charge maximale de la banque de batterie (en Joules)
        percent :       Pourcentage de la capacité maximale de la banque de batteries au début du cycle (en valeur décimale 80% = 0.8)
        min_percent :   Pourcentage minimale de la capacité de la banque de batteries à ne absolument pas dépasser 
        resistance :    Resistance interne de la banque de batterie (en Ohm), peut être 0 pour considérer une batterie sans pertes
        maxChCurrent :  Courant maximum permis en recharge. Est ignoré si la puissance en recharge ne peut pas être distribuée autrement (secondaire plein ou absent)
        maxDisCurrent : Courant maximum permis en décharge. Est ignoré si la puissance demandée ne peut provenir d'ailleur (secondaire vide ou absent)
        time_step :     Pas de temps de la simulation, doit être absolument identique pour toutes les composantes

    Paramètres de sortie (obtenus avec les méthodes correspondantes):
        getVoltage()        : Retourne la tension externe (voltage; en V) de la batterie, au pas de simulation courant
        getMaxVoltage()     : Retourne la tension lorsque la batterie est complètement chargée
        getEnergy()         : Retourne l'énergie totale (energy; en Joules) contenue dans la batterie, au pas de simulation courant
        getMinEnergy()      : Retourne la valeur minimale acceptable de l'énergie emmagasinée
        getDeltaEnergy()    : Retourne la plage d'énergie (maxEnergyHold - minEnergyHold; en Joules) qui a été utilisée durant le cycle, au pas de simulation courant
        getPercent()        : Retourne l'état de charge de la batterie en pourcentage, au pas de simulation courant
        getStartEnergy()    : Retourne l'énergie à l'état inital de la batterie (initEnergy; en Joules)
        getCurrent ()       : Retourne le courant (current; en A) de la batterie, au pas de simulation courant
        getPowerLoss()      : Retourne la puissance dissipée (powerLoss; en W) de la batterie, au pas de simulation courant
        getTotalLoss()      : Retourne la puissance totale dissipée (sumLoss; en W) de la batterie, au pas de simulation courant
        isEmpty()           : Retourne Vrai (True) si l'état de charge de la batterie est plus petite ou égale au minimum défini (min_percent), Faux (False) sinon.
        isFull()            : Retourne Vrai (True) si l'état de charge de la batterie est plus grand ou égale au maximum défini (capacity), Faux (False) sinon.
"""
class Battery:
    def __init__(self,batType, V_nominal, capacity, percent, min_percent, resistance, maxChCurrent, maxDisCurrent, time_step):
        # Paramètres fixes à l'initialisation
        self.V_nominal = V_nominal                          # Voltage nominal
        self.capacity = capacity                            # En joule
        self.time_step = time_step                          # Pas de temps de la simulation
        self.resistance = resistance                        # Résistance interne, mettre à 0 pour ignorer
        self.maxChCurrent = maxChCurrent                    # Courant maximal en recharge (en A)
        self.maxDisCurrent = maxDisCurrent                  # Courant maximal en décharge (en A)
        self.initEnergy = capacity * percent                # Energie disponible au debut de la simulation
        self.min_percent = min_percent                      # Niveau de charge minimale acceptable
        self.batType = batType                              # Type de batterie

        # modélisation de la batterie - Valeur pour une batterie au plomb à décharge profonde
        # y = order3 * x^3 + order2 * x^2 + order1 * x + order0 
        if batType == 1:    # Paramètres pour batterie LiFePO4 (Valide entre 0.17 et 1)
            self.order3 = 0.1667        
            self.order2 = -0.3226
            self.order1 = 0.2302
            self.order0 = 0.9706

        elif batType == 2:  # Paramètres pour batteries Plomb NMC
            self.order3 = 0.2345        
            self.order2 = -0.2389
            self.order1 = 0.201
            self.order0 = 0.9582

        else:               # Paramètres pour batteries Plomb AGM
            self.order3 = 0.5667        
            self.order2 = -0.9293
            self.order1 = 0.5637
            self.order0 = 0.8889

        # Paramètres variables durant la simulation
        self.energy = self.initEnergy                                           # Energie présentement emmagasinée
        self.maxEnergyHold = 0                                                  # Stockage de la valeur maximale d'energie emmangasinee
        self.minEnergyHold = float("inf")                                       # Stockage de la valeur minimale d'energie emmangasinee
        self.percent = self.energy / self.capacity                              # Percentage actuelle de la batterie
        self.intVoltage = self.V_nominal * self.polyApprox(self.percent)        # Tension interne   
        self.voltage = self.intVoltage                                          # Tension au départ, sans charge
        self.maxVoltage = self.V_nominal * self.polyApprox(1)                   # Tension maximale
        self.minVoltage = self.V_nominal * self.polyApprox(self.min_percent)    # Tension minimale
        self.current = 0                                                        # Courant au départ, sans charge
        self.powerLoss = 0                                                      # Puissance perdue presentement par la resistance interne
        self.sumLoss  = 0                                                       # Energie totale perdue par la resistance interne de la batterie
        self.batEmpty = (self.intVoltage <= self.minVoltage)                    # TRUE si la charge de la batterie est inferieur a la valeur minimale imposee
        self.batFull = (self.intVoltage >= self.maxVoltage)                     # TRUE si la charge de la batterie est superieur a la valeur maximale imposee
        
    def updateModel(self, order3, order2, order1, order0):
        self.order3 = order3                                                    
        self.order2 = order2
        self.order1 = order1
        self.order0 = order0
        # Recalcul les parametres
        self.intVoltage = self.V_nominal * self.polyApprox(self.percent)        # Tension interne   
        self.voltage = self.intVoltage                                          # Tension au départ, sans charge
        self.maxVoltage = self.V_nominal * self.polyApprox(1)                   # Tension maximale
        self.minVoltage = self.V_nominal * self.polyApprox(self.min_percent)    # Tension minimale
    
    def powerTransfert(self, power):
        self.current = power / self.voltage                                 # Courant actuel
        self.powerLoss = abs(self.resistance * self.current**2)             # Perte de puissance 
        self.sumLoss += self.time_step * self.powerLoss                     # Total des pertes
        self.energy += (power - self.powerLoss) * self.time_step            # Energie emmagasinee 
        self.percent = self.energy / self.capacity                          # Pourcentage de charge 
        self.intVoltage = self.V_nominal * self.polyApprox(self.percent)    # Tension interne de la batterie (Source equivalente Thevenin)
        self.voltage = self.intVoltage + (self.resistance * self.current)   # Tension externe (Directement mesurable)

        # Etat de charge de la batterie
        self.batEmpty = (self.intVoltage <= self.minVoltage)                # TRUE si la charge de la batterie est inferieur a la valeur minimale imposee                
        self.batFull = (self.intVoltage >= self.maxVoltage)                 # TRUE si la charge de la batterie est superieur a la valeur maximale imposee

        # Mesure de la charge maximale et minimale emmagasinée
        if self.energy > self.maxEnergyHold:
            self.maxEnergyHold = self.energy
        if self.energy < self.minEnergyHold:
            self.minEnergyHold = self.energy

    def polyApprox(self, x):
        return (self.order3*(x**3) + self.order2*(x**2) + self.order1*x + self.order0)

    """ 
    Fonction permettant l'accès aux variables internes de la classe
    Préférable aux accès directs puisque élimine le risque d'écraser involontairement des données
    (valeur = objet.getVoltage() est préféré à valeur = objet.voltage)
    """
    def getVoltage(self):       # Retourne la tension à l'itération actuelle
        return self.voltage

    def getMaxVoltage(self):
        return self.maxVoltage
        
    def getEnergy(self):        # Retourne l'energie stockée à l'itération actuelle
        return self.energy
        
    def getStartEnergy(self):   # Retourne l'energie stockée au départ
        return self.initEnergy
    
    def getMinEnergy(self):
        return self.capacity * self.min_percent

    def getCurrent(self):       # Retourne le courant à l'itération actuelle
        return self.current
        
    def getPowerLoss(self):     # Retourne la puissance perdue à l'itération actuelle
        return self.powerLoss
        
    def getTotalLoss(self):     # Retourne le cumul de la puissance perdue 
        return self.sumLoss

    def isEmpty(self):          # Retourne TRUE si la batterie est vide
        return self.batEmpty
    
    def isFull(self):           # Retourne TRUE si la batterie est pleine
        return self.batFull

    def getPercent(self):       # Retourne l'état de charge de la batterie à l'itération actuelle
        return self.percent
    
    def getDeltaEnergy(self):    # Retourne la plus grande différence d'énergie mesurée 
        return self.maxEnergyHold - self.minEnergyHold

""" Modèle du condensateur

    Le modèle du condensateur est basé sur son équivalent Thévenin. De l'extérieur, le condensateur est une source à deux bornes (+) Vcap (-).
    Le modèle inclut un source idéale (Tension interne; Vint) variant selon l'équation caractéristique des condensateurs et une résistance interne (Rint).
    Notes : 
        Les courants maximaux ne sont pas définis, car ils sont largement supérieurs à toutes les autres composantes et ne seront pas utilisés par la logique de gestion
        Durant le dimensionnement, l'état de charge initiale est considéré à 100% et 1 GF de capacité, les autres paramètres sont ceux définis par l'utilisateur
            L'état de charge de 90% surestime légérement la capacité nécessaire, ce qui est préférable aux options alternatives

    Schéma du condensateur
            Équation équivalente : Vbat = R*I + Vint = R*I + sqrt(2*E/C)
                R : Resistance (Ohm),     I : Courant (A),    E : Energie emmagasinée (J),      C: Capacitance (F)

     -----/\/\------
     |    Rint     |
    (+)           (+)
    Vint          Vcap = sqrt(2*E/C)
    (-)           (-)
     |             |
     ---------------

    Initialisation (code dans def __init__):
        Contient tous les paramètres définissant un condensateur étant nécessaire pour la simulation
        Un objet du type condensat est crée. Ce objet se souvient de ses paramètres initiaux et de son état actuel.

    Fonctionnement (à chaque pas de la simulation): 

    La méthode powerTransfert(power) est appliquée et effectue les étapes suivantes
        1) Selon la puissance consommée/régénérée et la tension externe du condensateur, le courant (current) est calculé.
        2) La perte resistive (powerLoss) est calculé et accumulée dans une variable (sumLoss) et ajouté/enlevé de la puissance consommée/régénérée
        3) L'énergie actuellement consommée/régénérée par le condensateur est ensuite retirée/ajoutée à l'énergie contenue dans celui-ci (energy)
        4) L'état de charge du condensateur (percent), la tension interne (intVoltage) et la tension externe (voltage) sont recalculés
        5) Les signaux de contrôles et la plage d'énergie utilisée durant le cycle sont mis-à-jour

    Paramètres d'entrée
        V_init :        Somme des tensions initiales de la banque de condensateurs
        farad :         Capacité de la banque de condensateurs (en Farads)
        resistance :    Résistance interne de la banque de condensateurs (en Ohm), peut être 0 pour considérer une composante idéale
        maxVoltage :    Tension maximale acceptable (en Volt, le plus souvent la tension permise par le fabricant)
        minVoltage  :   Tension maximale acceptable (en Volt, le plus souvent 0, mais peut varier selon l'utilisation)
        time_step :     Pas de temps de la simulation, doit être absolument identique pour toutes les composantes

    Paramètres de sortie (obtenus avec les méthodes correspondantes):
        getVoltage()        : Retourne la tension externe (voltage; en V) de la banque de condensateurs, au pas de simulation courant
        getMaxVoltage()     : Retourne la tension lorsque la capacité est complètement chargée
        getEnergy()         : Retourne l'énergie totale (energy; en Joules) contenue dans la banque de condensateurs, au pas de simulation courant
        getMinEnergy()      : Retourne la valeur minimale acceptable de l'énergie emmagasinée
        getDeltaEnergy()    : Retourne la plage d'énergie (maxEnergyHold - minEnergyHold; en Joules) qui a été utilisée durant le cycle, au pas de simulation courant
        getPercent()        : Retourne l'état de charge de la banque de condensateurs en pourcentage, au pas de simulation courant
        getStartEnergy()    : Retourne l'énergie à l'état inital de la banque de condensateurs (initEnergy; en Joules)
        getCurrent ()       : Retourne le courant (current; en A) de la banque de condensateurs, au pas de simulation courant
        getPowerLoss()      : Retourne la puissance dissipée (powerLoss; en W) de la banque de condensateurs, au pas de simulation courant
        getTotalLoss()      : Retourne la puissance totale dissipée (sumLoss; en W) de la banque de condensateurs, au pas de simulation courant
        isEmpty()           : Retourne Vrai (True) si l'état de charge de la banque de condensateurs est plus petite ou égale au minimum défini (min_percent), Faux (False) sinon.
        isFull()            : Retourne Vrai (True) si l'état de charge de la banque de condensateurs est plus grand ou égale au maximum défini (capacity), Faux (False) sinon.
"""
class Capacitor:
    def __init__(self, V_init, farad, resistance, maxVoltage, minVoltage, time_step):
        # Paramètres fixes à l'initialisation
        self.farad = farad                                          # Capacite (en Farad)
        self.resistance = resistance                                # Resistance interne
        self.maxVoltage = maxVoltage                                # Tension maximale permise
        self.minVoltage = minVoltage                                # Tension minimale permise
        self.maxEnergy =  0.5 * self.farad * self.maxVoltage**2     # Energie maximale emmagasinable (maximum absolue)
        self.minEnergy =  0.5 * self.farad * self.minVoltage**2     # Energie minimale emmagasinable (minimum absolue)
        self.initEnergy = 0.5 * self.farad * V_init**2              # Energie  emmagasinable au départ
        self.min_percent = (minVoltage**2) / (maxVoltage**2)        # Niveau de charge minimale acceptable
        self.time_step = time_step                                  # Pas de temps de la simulation
        
        # Paramètres variables durant la simulation
        self.intVoltage = V_init                                    # Tension interne (non mesurable, equivalent Thevenin)
        self.voltage = self.intVoltage                              # Tension externe (measurable)
        self.energy = 0.5 * self.farad * self.intVoltage**2         # Energie actuellement emmagasinee
        self.maxEnergyHold = 0                                      # Energie maximale emmagasine (maximum atteint par l'essaie)
        self.minEnergyHold = float("inf")                           # Stockage de la valeur minimale d'energie emmangasinee
        self.percent = self.energy / self.maxEnergy                 # Pourcentage de charge de la capacite
        self.current = 0                                            # Courant au départ, sans charge
        self.powerLoss = 0                                          # Puissance perdue presentement par la resistance interne
        self.sumLoss  = 0                                           # Total de l'energie perdue presentement par la resistance interne
        self.capEmpty = (self.intVoltage <= self.minVoltage)        # TRUE si la charge de la capacite est inferieur a la valeur minimale imposee   
        self.capFull = (self.intVoltage >= self.maxVoltage)         # TRUE si la charge de la capacite est superieur a la valeur maximale imposee

    def powerTransfert(self, power):
        self.current = power / self.voltage                                 # Courant actuel
        self.powerLoss = abs(self.resistance * self.current**2)             # Perte de puissance 
        self.sumLoss += self.time_step * self.powerLoss                     # Total des pertes
        self.energy += (power - self.powerLoss) * self.time_step            # Energie emmagasinee 
        self.percent = self.energy / self.maxEnergy                         # Pourcentage de charge 
        self.intVoltage = (2 * self.energy / self.farad)**0.5               # Tension interne de la capacite (non mesurable, equivalent Thevenin)
        self.voltage = self.intVoltage + (self.resistance * self.current)   # Tension externe (Directement mesurable)
        # Etat de charge de la capacite
        self.capEmpty = (self.intVoltage <= self.minVoltage)                # TRUE si la charge de la capacite est inferieur a la valeur minimale imposee   
        self.capFull = (self.intVoltage >= self.maxVoltage)                 # TRUE si la charge de la capacite est superieur a la valeur maximale imposee

        # Mesure de la charge maximale et minimale emmagasinée
        if self.energy > self.maxEnergyHold:
            self.maxEnergyHold = self.energy
        if self.energy < self.minEnergyHold:
            self.minEnergyHold = self.energy

    """ 
    Fonctions permettant l'accès aux variables internes de la classe
    Préférable aux accès directs puisque élimine le risque d'écraser involontairement des données
    (valeur = objet.getVoltage() est préféré à valeur = objet.voltage)
    """
    def getVoltage(self):       # Retourne la tension à l'itération actuelle
        return self.voltage

    def getMaxVoltage(self):
        return self.maxVoltage
        
    def getEnergy(self):        # Retourne l'energie stockée à l'itération actuelle
        return self.energy
        
    def getStartEnergy(self):   # Retourne l'energie stockée au départ
        return self.initEnergy

    def getMinEnergy(self):
        return self.minEnergy

    def getCurrent(self):       # Retourne le courant à l'itération actuelle
        return self.current
        
    def getPowerLoss(self):     # Retourne la puissance perdue à l'itération actuelle
        return self.powerLoss
        
    def getTotalLoss(self):     # Retourne le cumul de la puissance perdue 
        return self.sumLoss

    def isEmpty(self):          # Retourne TRUE si la batterie est vide
        return self.capEmpty
    
    def isFull(self):           # Retourne TRUE si la batterie est pleine
        return self.capFull

    def getPercent(self):       # Retourne l'état de charge de la batterie à l'itération actuelle
        return self.percent
    
    def getDeltaEnergy(self):    # Retourne la plus grande différence d'énergie mesurée 
        return (self.maxEnergyHold - self.minEnergyHold)

""" Modèle du convertisseur DC-DC (ou du second moteur)

    Le modèle du convertisseur permet de transférer de la puissance entre deux noeuds de tension différentes (Vmain <-> Valt). 
    Le modèle est fortement généralisé pour être appliquable à la majorité des produits.

    Schéma du convertisseur

            --------
     -------|      | ------
     |      |      |      |
    (+)     |      |     (+)
    Vmain   | *eff |     Valt
    (-)     |      |     (-)
     |      |      |      |
     -------|      |-------
            --------

    Initialisation (code dans def __init__):
        Contient tous les paramètres définissant un convertiseur général étant nécessaire pour la simulation
        Un objet du type convertisseur est crée. Ce objet se souvient de ses paramètres initiaux et de son état actuel.

    Fonctionnement (à chaque pas de la simulation): 

    La méthode update(mainVoltage, altVoltage, altEmpty, altFull) est appliquée et effectue les étapes suivantes
        1) Vérifie si les tensions au primaire/secondaire sont non-nul et applique un tension faible sinon (évite les divisions par 0)
        2) Détermine la puissance maximale transférable par le convertisseur pour l'état courant du système
        3) Si la tension au secondaire est plus petite que le minimum acceptable, précharge lentement le stockage secondaire (utile pour les condensateurs)
        4) Détermine si le stockage secondaire peut prendre/fournir de l'énergie

    La méthode powerConversion(power) est appliquée lors du transfert d'énergie au secondaire
        1) La perte de puissance (powerLoss) est calculé et accumulée dans une variable (totalPowerLoss) et ajouté/enlevé de la puissance consommée/régénérée
        2) Retourne la puissance à transférer (puissance entrée - puissance perdue)

    Paramètres d'entrée

        efficiency :    Efficacité du convertisseur 
        maxPower :      Puissance maximale transférable par le convertisseur
        hysteresis :    Différence minimale entre l'activation/désactivation de la recharge ou de la décharge pour éviter les changements rapides
        time_step :     Pas de temps de la simulation, doit être absolument identique pour toutes les composantes
        limits :        Vecteur des limites de tension/courant du convertisseur 
                        [mainSide_minVoltage, mainSide_maxVoltage, mainSide_maxCurrent, altSide_minVoltage, altSide_maxVoltage, altSide_maxCurrent]

                        Du coté de l'alimentation principale
                            mainSide_minVoltage : Tension minimale permise lors du transfert primaire -> secondaire
                            mainSide_maxVoltage : Tension maximale permise lors du transfert secondaire -> primaire
                            mainSide_maxCurrent : Courant maximal permis pour toute les tensions permises

                        Du coté de l'alimentation secondaire (alt)
                            altSide_minVoltage : Tension minimale permise lors du transfert secondaire -> primaire
                            altSide_maxVoltage : Tension maximale permise lors du transfert primaire -> secondaire
                            altSide_maxCurrent : Courant maximal permis pour toute les tensions permises

    Paramètres de sortie (obtenus avec les méthodes correspondantes):
        getPowerLoss()          : Retourne la puissance dissipée (powerLoss; en W) par le convertisseur, au pas de simulation courant
        getTotalLoss()          : Retourne la puissance totale dissipée (sumLoss; en W) par le convertisseur, au pas de simulation courant
        getAltSideMinVoltage()  : Tension minimale acceptable du coté du secondaire
        getPowerLimit()         : Retourne la puissance maximale transférable, au pas de simulation courant
        getPowerDraw()          : Puissance transférée pour la précharge du secondaire
        isChargeable()          : Retourne Vrai (True) si le secondaire peut être rechargé (min_percent), Faux (False) sinon.
        isDischargeable()       : Retourne Vrai (True) si le secondaire peut être déchargé (min_percent), Faux (False) sinon.
"""
class Converter:
    def __init__(self,limits, altMinVoltage, efficiency, maxPower, hysteresis, time_step):
        # Paramètres tension/courant limites - fixes à l'initialisation
        self.mainSide_minVoltage = limits[0]
        self.mainSide_maxVoltage = limits[1]
        self.mainSide_maxCurrent = limits[2]
        self.altSide_minVoltage = max(limits[3], altMinVoltage, 0.1)
        self.altSide_maxVoltage = limits[4]
        self.altSide_maxCurrent = limits[5]
        
        # Paramètres généraux - fixes à l'initialisation
        self.time_step = time_step
        self.efficiency = efficiency
        self.maxPower = maxPower
        self.hysteresis = hysteresis

        # Paramètres variables durant la simulation
        self.powerLimit = 0
        self.altVoltage = 0
        self.mainVoltage = 0
        self.powerDraw = 0
        self.powerLoss = 0
        self.totalPowerLoss = 0
        self.previousCHState = False
        self.previousDISCHState = False
        self.chargeEnabled = False
        self.dischargeEnabled = False

    def powerConversion(self, power):
        self.powerLoss = abs(power * (1-self.efficiency))
        self.totalPowerLoss += self.powerLoss * self.time_step
        return power - self.powerLoss
    
    def update(self, mainVoltage, altVoltage, altEmpty, altFull):
        self.mainVoltage = mainVoltage if mainVoltage > 0 else 0.1          # Evite les divisions par 0
        self.altVoltage = altVoltage if altVoltage > 0 else 0.1             # Evite les divisions par 0
        self.powerLimit = min(self.mainVoltage * self.mainSide_maxCurrent,  # Determine la puissance maximale pour l'etat actuel
                            self.altVoltage * self.altSide_maxCurrent,
                            self.maxPower)
        
        # Controle de la precharge de la la reserve secondaire
        initialChargingScheme = 1 - (self.altVoltage / self.altSide_minVoltage)
        # Determine si on a besoin de precharger la reserve secondaire    
        self.powerDraw = self.powerLimit * initialChargingScheme if initialChargingScheme > 0 else 0
        
        if self.previousCHState:
            self.chargeEnabled = ((self.altVoltage < self.altSide_maxVoltage) and not(altFull))
        else:
            self.chargeEnabled = ((self.altVoltage < (self.altSide_maxVoltage - self.hysteresis)) and not(altFull))

        if self.previousDISCHState:
            self.dischargeEnabled = ((self.altVoltage > self.altSide_minVoltage) and not(altEmpty))
        else:
            self.dischargeEnabled = ((self.altVoltage > (self.altSide_minVoltage + self.hysteresis)) and not(altEmpty))

        self.previousCHState = self.chargeEnabled
        self.previousDISCHState =  self.dischargeEnabled
        

    """ 
    Fonctions permettant l'accès aux variables internes de la classe Converter
    Préférable aux accès directs puisque élimine le risque d'écraser involontairement des données
    (valeur = objet.getPowerLoss() est préféré à valeur = objet.powerLoss)
    """
    def getPowerLoss(self):
        return self.powerLoss
                
    def getTotalLoss(self):
        return self.totalPowerLoss

    def getAltSideMinVoltage(self):
        return self.altSide_minVoltage

    def getPowerLimit(self):
        return self.powerLimit

    def getPowerDraw(self):
        return self.powerDraw

    def isChargeable(self):
        return self.chargeEnabled

    def isDischargeable(self):
        return self.dischargeEnabled

""" Logique du transfert de puissance

    Initialisation (code dans def __init__):
        Contient tous les paramètres définissant un convertiseur général étant nécessaire pour la simulation
        Un objet du type convertisseur est crée. Ce objet se souvient de ses paramètres initiaux et de son état actuel.

    Fonctionnement (à chaque pas de la simulation): 

    La méthode update(mainVoltage, altVoltage, altEmpty, altFull) est appliquée et effectue les étapes suivantes
        1) Vérifie si les tensions au primaire/secondaire sont non-nul et applique un tension faible sinon (évite les divisions par 0)
        2) Détermine la puissance maximale transférable par le convertisseur pour l'état courant du système
        3) Si la tension au secondaire est plus petite que le minimum acceptable, précharge lentement le stockage secondaire (utile pour les condensateurs)
        4) Détermine si le stockage secondaire peut prendre/fournir de l'énergie

    La méthode powerConversion(power) est appliquée lors du transfert d'énergie au secondaire
        1) La perte de puissance (powerLoss) est calculé et accumulée dans une variable (totalPowerLoss) et ajouté/enlevé de la puissance consommée/régénérée
        2) Retourne la puissance à transférer (puissance entrée - puissance perdue)

    Paramètres d'entrée

        efficiency :    Efficacité du convertisseur 
        maxPower :      Puissance maximale transférable par le convertisseur
        hysteresis :    Différence minimale entre l'activation/désactivation de la recharge ou de la décharge pour éviter les changements rapides
        time_step :     Pas de temps de la simulation, doit être absolument identique pour toutes les composantes
        limits :        Vecteur des limites de tension/courant du convertisseur 
                        [mainSide_minVoltage, mainSide_maxVoltage, mainSide_maxCurrent, altSide_minVoltage, altSide_maxVoltage, altSide_maxCurrent]

                        Du coté de l'alimentation principale
                            mainSide_minVoltage : Tension minimale permise lors du transfert primaire -> secondaire
                            mainSide_maxVoltage : Tension maximale permise lors du transfert secondaire -> primaire
                            mainSide_maxCurrent : Courant maximal permis pour toute les tensions permises

                        Du coté de l'alimentation secondaire (alt)
                            altSide_minVoltage : Tension minimale permise lors du transfert secondaire -> primaire
                            altSide_maxVoltage : Tension maximale permise lors du transfert primaire -> secondaire
                            altSide_maxCurrent : Courant maximal permis pour toute les tensions permises

    Paramètres de sortie (obtenus avec les méthodes correspondantes):
        getPowerLoss()      : Retourne la puissance dissipée (powerLoss; en W) par le convertisseur, au pas de simulation courant
        getTotalLoss()      : Retourne la puissance totale dissipée (sumLoss; en W) par le convertisseur, au pas de simulation courant
        getPowerLimit()     : Retourne la puissance maximale transférable, au pas de simulation courant
        getPowerDraw()      : Puissance transférée pour la précharge du secondaire
        isChargeable()      : Retourne Vrai (True) si le secondaire peut être rechargé (min_percent), Faux (False) sinon.
        isDischargeable()   : Retourne Vrai (True) si le secondaire peut être déchargé (min_percent), Faux (False) sinon.
"""
class PowerSplitter:
    def __init__(self, mainChLimitCurrent, mainDischLimitCurrent, isBattery, time_step):
        # Paramètres fixes à l'initialisation
        self.mainChLimitCurrent = mainChLimitCurrent
        self.mainDischLimitCurrent = mainDischLimitCurrent
        self.isBattery = isBattery
        self.time_step = time_step

        # Paramètres variables de calcul
        self.converterPowerLimit = 0
        self.converterPowerDraw = 0
        self.chEnabled = False
        self.dischEnabled = False
        self.powerFromMain_duration = 0
        self.powerToMain_duration = 0
        self.powerFromSecondary_duration = 0
        self.powerToSecondary_duration = 0
        self.mainLimitChPower = 0
        self.mainLimitDischPower = 0
        self.nodeVoltage = 0

        # Paramètres variables de sortie
        self.powerToBattery = 0
        self.powerToConverter = 0
        
    def update(self, converterPowerLimit, converterPowerDraw, chEnabled, dischEnabled, nodeVoltage):
        self.converterPowerLimit = converterPowerLimit
        self.converterPowerDraw = converterPowerDraw
        self.chEnabled = chEnabled
        self.dischEnabled = dischEnabled
        self.nodeVoltage = nodeVoltage
        self.mainLimitChPower = (self.mainChLimitCurrent * self.nodeVoltage)
        self.mainLimitDischPower = -1*(self.mainDischLimitCurrent * self.nodeVoltage)

    def calculatePowerSplit(self, power):
        # reset values
        self.powerToBattery = 0
        self.powerToConverter = 0
        if power > 0:    # Selection du fonctionnement en recharge
            if self.isBattery:  # Si la source d'energie principale est une/des batterie(s)
                if self.chEnabled: # Si le stockage secondaire peu accepter de l'energie (batterie ou cap)
                    self.powerToBattery = power if power <= self.mainLimitChPower else self.mainLimitChPower
                    powerRemaining = power -  self.powerToBattery
                    self.powerToConverter = powerRemaining if powerRemaining <= self.converterPowerLimit else self.converterPowerLimit
                    self.powerToBattery += (powerRemaining - self.powerToConverter) # Si il reste de la puissance à distribuer, l'envoyer dans la source principale
                else:
                    self.powerToBattery =  power # Si la source secondaire ne peut accepter plus d'energie, envoyer tout dans la source principale
            else: 
                self.powerToConverter = power # Si la source principale est une generatrice qui ne peut pas accepter d'énergie

        if power < 0:
            if self.dischEnabled:
                self.powerToBattery = power if power >= self.mainLimitDischPower else self.mainLimitDischPower
                powerRemaining = power -  self.powerToBattery
                self.powerToConverter = powerRemaining if powerRemaining >= (-1*self.converterPowerLimit) else (-1*self.converterPowerLimit)
                self.powerToBattery += (powerRemaining - self.powerToConverter) # Si il reste de la puissance à distribuer, l'envoyer dans la source principale
            else:
                self.powerToBattery = power - self.converterPowerDraw
                self.powerToConverter = self.converterPowerDraw

        # Calcul du temps passé dans les différents modes recharge/decharge pour chaque stockage
        if  self.powerToBattery > 0:
            self.powerToMain_duration += self.time_step
        if self.powerToBattery < 0:
            self.powerFromMain_duration += self.time_step
        if  self.powerToConverter > 0:
            self.powerToSecondary_duration += self.time_step
        if self.powerToConverter < 0:
            self.powerFromSecondary_duration += self.time_step


    """ 
    Fonctions permettant l'accès aux variables internes de la classe PowerSplitter
    Préférable aux accès directs puisque élimine le risque d'écraser involontairement des données
    (valeur = objet.getPowerToPrimary() est préféré à valeur = objet.powerToBattery)
    """
    def getPowerToMainDuration(self):
        return self.powerToMain_duration

    def getPowerFromMainDuration(self):
        return self.powerFromMain_duration

    def getPowerToSecondaryDuration(self):
        return self.powerToSecondary_duration

    def getPowerFromSecondaryDuration(self):
        return self.powerFromSecondary_duration

    def getPowerToPrimary(self):
        return self.powerToBattery

    def getPowerToSecondary(self):
        return self.powerToConverter

    def getPowerToPrimary(self):
        return self.powerToBattery


"""
    Initialisation (code dans def __init__):
        Contient tous les paramètres définissant la ligne du temps et la puissance correspondante à chaque point
        Les vecteurs de temps et de puissance sont calculés une seule fois au début de la simulation

    Paramètres d'entrée de l'init
        timeStep :    pas de temps entre les échantillons

    Paramètres d'entrée de l'update
        time :    temps en secondes de chacun des plateaux de puissance
        data :    valeur en watt de la puissance correspondante à chaque plateu
"""


class Timeline:
    def __init__(self, timeStep):
        self.timeStep = timeStep
        self.dataPoints = []
        self.timeline = []

    def update(self, data, time):
        if len(data) == len(time):
            self.dataPoints = data
            self.timeline = time
        else:
            print("Error, not same length")

    def linspace(self, startPt, endPt, nbStep):
        output = [startPt]
        stepRise = (endPt - startPt) / nbStep
        for i in range(1, nbStep):
                output += [output[i-1] + stepRise]
        return output

    # Fonction générant des échelons
    def generate(self):
        self.dataLine = []
        for i in range(len(self.dataPoints)):
                self.dataLine += [self.dataPoints[i]]*int(self.timeline[i]/self.timeStep)
        return self.dataLine

    """
    # Fonction générant des rampes (pour comparaison au banc de test)
    def generate(self):
        self.dataLine = []
        for i in range(1, len(self.dataPoints)):
                self.dataLine += self.linspace(self.dataPoints[i-1], self.dataPoints[i], int(self.timeline[i]/self.timeStep))
        return self.dataLine
    """

#Définition des fonctions utilitaires---------------------------------------------------------------------------------------
# fonction pour convertir une chaine de caractères en une liste de nombres à virgule
# Exemple : "1,2,3,4" --> [1.0,2.0,3.0,4.0]
def inputString2Float(str_input):
	x = str_input.split(",")
	return [float(i) for i in x]

# fonction pour convertir une liste de nombres à virgule en une chaine de caractères
# Exemple : [1.0,2.0,3.0,4.0] --> "1,2,3,4"
def outputFloat2String(input_liste):
	test = [str(i) for i in input_liste]
	outputString = ""

	for i in range(len(test)):
		outputString = outputString + test[i] + ","

	return outputString[:len(outputString)-1]

# Fonction pour stocker une valeur calculée dans un fichier texte suivi d'un saut de ligne. Une valeur à la fois
# exemple : log_to_file("output.txt",data)
def log_to_file(file_name, value):
    f = open("{}".format(file_name), "a")
    f.write("{}\n".format(value))
    f.close()

#Fin de la définition des fonctions utilitaires---------------------------------------------------------------------------------------

# Début de la section des calculs ----------------------------------------------------------------------------------------------------

start_time = time.time() # Point de départ du timer pour mesurer la vitesse de simulation

#Valeurs d'entrées: Chaines de caractères provenant du code VBA d'Excel
useCase = sys.argv[1] #Use Case

if (useCase == "1") or (useCase == "2"):
    paramFixeStr = sys.argv[2]
    paramPowerStr = sys.argv[3]
    timePtStr = sys.argv[4]

    paramFixe = inputString2Float(paramFixeStr)
    paramPower = inputString2Float(paramPowerStr)
    timePt = inputString2Float(timePtStr)

    #decode parameters
    timestep = paramFixe[0]
    mainPowerSource = bool(paramFixe[1])
    storageComponent = int(paramFixe[2])
    nbrCycles = int(paramFixe[3])
    VnominalGen = paramFixe[4]
    VnominalBat = paramFixe[5]
    maxEnergyBat = paramFixe[6] 
    batPercentInit = paramFixe[7]
    batPercentMin = paramFixe[8]
    resistanceBat = paramFixe[9]
    maxChargeCurrent = paramFixe[10]
    maxDischargeCurrent = paramFixe[11]
    capFarad = paramFixe[12]
    resistanceCap = paramFixe[13]
    initVoltageCap = paramFixe[14]
    maxVoltageCap = paramFixe[15]
    minVoltageMainDCDC = paramFixe[16]
    maxVoltageMainDCDC = paramFixe[17]
    maxCurrentMainDCDC = paramFixe[18]
    minVoltageSecDCDC = paramFixe[19]
    maxVoltageSecDCDC = paramFixe[20]
    maxCurrentSecDCDC = paramFixe[21]
    efficiencyDCDC = paramFixe[22]
    maxPowerDCDC = paramFixe[23]
    hysteresis = paramFixe[24]
    batType = paramFixe[25]
    mainChLimitCurrent = paramFixe[26]
    mainDischLimitCurrent = paramFixe[27]
    minVoltageCap = paramFixe[28]
else:
	exit()


#Initialistion des composantes
#Échantillonnage du cycle de puissance
timeline = Timeline(timestep)
timeline.update(paramPower, timePt)
power = timeline.generate()

if useCase == "1":
    #Section stockage primaire
    if mainPowerSource:     # Source primaire est une batterie
        primaryStorage = Battery(batType, VnominalBat, maxEnergyBat, batPercentInit, batPercentMin, resistanceBat, maxChargeCurrent, maxDischargeCurrent, timestep)
    else:                   # Source primaire est une generatrice (batterie infinie, resistance nulle, non inversible)
        primaryStorage = Battery(batType, VnominalGen, 999999999999, 1, 0, 0, 0, 999999, timestep)
        primaryStorage.updateModel(0, 0, 0, 1)
    
    #section Secondaire
    if storageComponent == 1:
        secondaryStorage = Battery(batType, VnominalBat, maxEnergyBat, batPercentInit, batPercentMin, resistanceBat, maxChargeCurrent, maxDischargeCurrent, timestep)
    if storageComponent == 0:
        secondaryStorage = Capacitor(initVoltageCap, capFarad, resistanceCap, maxVoltageCap, minVoltageCap, timestep)
    
    
elif useCase == "2":
    #Section stockage primaire
    if mainPowerSource:     # Source primaire est une batterie
        primaryStorage = Battery(batType, VnominalBat, maxEnergyBat, batPercentInit, batPercentMin, resistanceBat, maxChargeCurrent, maxDischargeCurrent, timestep)
    else:                   # Source primaire est une generatrice (batterie infinie, resistance nulle, non inversible)
        primaryStorage = Battery(batType, VnominalGen, 999999999999, 1, 0, 0, 0, 999999, timestep)
        primaryStorage.updateModel(0, 0, 0, 1)

    #section Secondaire
    if storageComponent == 1:
        secondaryStorage = Battery(batType, VnominalBat, 999999999999, 0.9, 0.9, resistanceBat, maxChargeCurrent, maxDischargeCurrent, timestep)
    if storageComponent == 0:
        secondaryStorage = Capacitor(0.9*maxVoltageCap, 999999999999, resistanceCap, maxVoltageCap, 0.9*maxVoltageCap, timestep)
else:
    exit()

"""
Initialisation de tous les vecteurs de stockages des données produites par le simulateur
"""
# Node current and voltage
main_voltage = []
main_current = []
main_powerLoss = []
main_totalPowerLoss = []
main_percent = []
main_energy = []

secondary_voltage = []
secondary_current = []
secondary_powerLoss = []
secondary_totalPowerLoss = []
secondary_percent = []
secondary_energy = []

# Converter
converter_powerLoss = []
converter_totalPowerLoss = []

# Power Transfert
timeVector = []
powerVector = []
powerToMain = []
powerToSecondary = []

# Signaux logique
main_isEmpty = []
main_isFull = []
secondary_isEmpty = []
secondary_isFull = []
secondary_chargeable = []
secondary_dischargeable = []

# Outputs spécifiques
powerToMainDuration = -1
powerFromMainDuration = -1
powerToSecondaryDuration = -1
powerFromSecondaryDuration = -1
mainEnergyDelta = -1
secondaryEnergyDelta = -1

lengthVector = len(power)
cycles = nbrCycles

decimation = 10000
timeElapsed = 0

"""
Cas spéciale : Il n'y a pas de stockage secondaire et donc pas de convertisseur
Sert à dimensionner les systèmes électriques à source unique
"""

if storageComponent == 2:
    for j in range(cycles):
        for i in range(lengthVector):
            primaryStorage.powerTransfert(power[i])

            #stockage in list
            # Node current and voltage
            main_voltage.append(primaryStorage.getVoltage())
            main_current.append(primaryStorage.getCurrent())
            main_powerLoss.append(primaryStorage.getPowerLoss())
            main_totalPowerLoss.append(primaryStorage.getTotalLoss())
            main_percent.append(primaryStorage.getPercent())
            main_energy.append(primaryStorage.getEnergy())

            # powerLine
            timeElapsed += timestep
            timeVector.append(timeElapsed)
            powerVector.append(power[i])

            # Signaux logique
            main_isEmpty.append(primaryStorage.isEmpty())
            main_isFull.append(primaryStorage.isFull())
    mainEnergyDelta = primaryStorage.getDeltaEnergy()
    minimalCapacity = -1

else:   # Cas normal : Stockage primaire et secondaire
    #section convertisseur
    converterLimits = [minVoltageMainDCDC, maxVoltageMainDCDC, maxCurrentMainDCDC, minVoltageSecDCDC, maxVoltageSecDCDC, maxCurrentSecDCDC]
    converter = Converter(converterLimits, minVoltageCap, efficiencyDCDC, maxPowerDCDC, hysteresis, timestep)

    #section stratégie de gestion d'énergie
    splitter = PowerSplitter(mainChLimitCurrent, mainDischLimitCurrent, mainPowerSource, timestep)
    #Execution du programme de calculs-------------------------------------------------------------------------------

    for j in range(cycles):
        for i in range(lengthVector):
            converter.update(primaryStorage.getVoltage(), secondaryStorage.getVoltage(), secondaryStorage.isEmpty(), secondaryStorage.isFull())
            splitter.update(converter.getPowerLimit(), converter.getPowerDraw(), 
                            converter.isChargeable(), converter.isDischargeable(), primaryStorage.getVoltage())
            splitter.calculatePowerSplit(power[i])
            primaryStorage.powerTransfert(splitter.getPowerToPrimary())
            secondaryStorage.powerTransfert(converter.powerConversion(splitter.getPowerToSecondary()))
            
            #stockage in list
            # Node current and voltage
            main_voltage.append(primaryStorage.getVoltage())
            main_current.append(primaryStorage.getCurrent())
            main_powerLoss.append(primaryStorage.getPowerLoss())
            main_totalPowerLoss.append(primaryStorage.getTotalLoss())
            main_percent.append(primaryStorage.getPercent())
            main_energy.append(primaryStorage.getEnergy())

            secondary_voltage.append(secondaryStorage.getVoltage())
            secondary_current.append(secondaryStorage.getCurrent())
            secondary_powerLoss.append(secondaryStorage.getPowerLoss())
            secondary_totalPowerLoss.append(secondaryStorage.getTotalLoss())
            secondary_percent.append(secondaryStorage.getPercent())
            secondary_energy.append(secondaryStorage.getEnergy())

            # Converter
            converter_powerLoss.append(converter.getPowerLoss())
            converter_totalPowerLoss.append(converter.getTotalLoss())

            
            # powerLine
            timeElapsed += timestep
            timeVector.append(timeElapsed)
            powerVector.append(power[i])
            
            # Power Transfert
            powerToMain.append(splitter.getPowerToPrimary())
            powerToSecondary.append(splitter.getPowerToSecondary())

            # Signaux logique
            main_isEmpty.append(primaryStorage.isEmpty())
            main_isFull.append(primaryStorage.isFull())
            secondary_isEmpty.append(secondaryStorage.isEmpty())
            secondary_isFull.append(secondaryStorage.isFull())
            secondary_chargeable.append(converter.isChargeable())
            secondary_dischargeable.append(converter.isDischargeable())

    powerToMainDuration = splitter.getPowerToMainDuration()
    powerFromMainDuration = splitter.getPowerFromMainDuration()
    powerToSecondaryDuration = splitter.getPowerToSecondaryDuration()
    powerFromSecondaryDuration = splitter.getPowerFromSecondaryDuration()
    mainEnergyDelta = primaryStorage.getDeltaEnergy()
    secondaryEnergyDelta = secondaryStorage.getDeltaEnergy()
 
    # Traitmement capacite de stockage du secondaire
    if storageComponent == 1:    # Si batterie
        minimalCapacity = secondaryEnergyDelta/(1-batPercentMin) / (3600 * secondaryStorage.V_nominal)
    elif storageComponent == 0:                   # Si capacite
        minRatio =  (converter.getAltSideMinVoltage()/ secondaryStorage.getMaxVoltage())**2
        minimalCapacity = 2 * (secondaryEnergyDelta/(1-minRatio)) / (secondaryStorage.maxVoltage**2)
    else:
        minimalCapacity = -1

# Post Traitement

# Decimation
decimateur = round((len(timeVector)/decimation)+0.5)

# Traitment nb de cycle
if (mainPowerSource and (useCase == "1")):
    current_energy = primaryStorage.getEnergy()
    start_energy = primaryStorage.getStartEnergy()
    minimumEnergy = primaryStorage.getMinEnergy()
    maxNbCycles = (start_energy - minimumEnergy) / (start_energy - current_energy)
else:
    maxNbCycles = -1


calc_time = time.time() - start_time 
# Envoi des données calculées vers Excel
# Les données sortantes doivent avoir le même format que les données entrantes, sois un string qui sépare les éléments de lignes par une virgule
# Par exemple : "Ligne1,Ligne2,Ligne3,Ligne4"
print(outputFloat2String(timeVector[::decimateur]))
print(outputFloat2String([-1* i for i in powerVector[::decimateur]]))

print(outputFloat2String(main_voltage[::decimateur]))
print(outputFloat2String([-1* i for i in main_current[::decimateur]]))
print(outputFloat2String(main_powerLoss[::decimateur]))
print(outputFloat2String(main_totalPowerLoss[::decimateur]))
print(outputFloat2String(main_percent[::decimateur]))
print(outputFloat2String(main_energy[::decimateur]))

print(outputFloat2String(secondary_voltage[::decimateur]))
print(outputFloat2String([-1* i for i in secondary_current[::decimateur]]))
print(outputFloat2String(secondary_powerLoss[::decimateur]))
print(outputFloat2String(secondary_totalPowerLoss[::decimateur]))
print(outputFloat2String(secondary_percent[::decimateur]))
print(outputFloat2String(secondary_energy[::decimateur]))

print(outputFloat2String([-1* i for i in powerToMain[::decimateur]]))
print(outputFloat2String([-1* i for i in powerToSecondary[::decimateur]]))

print(outputFloat2String(main_isEmpty[::decimateur]))
print(outputFloat2String(main_isFull[::decimateur]))
print(outputFloat2String(secondary_isEmpty[::decimateur]))
print(outputFloat2String(secondary_isFull[::decimateur]))
print(outputFloat2String(secondary_chargeable[::decimateur]))
print(outputFloat2String(secondary_dischargeable[::decimateur]))

print(outputFloat2String(converter_powerLoss[::decimateur]))
print(outputFloat2String(converter_totalPowerLoss[::decimateur]))

end_time = time.time() - start_time 
specific_ouputs = [maxNbCycles, minimalCapacity, powerToMainDuration, powerFromMainDuration, 
                    powerToSecondaryDuration, powerFromSecondaryDuration, calc_time, end_time, mainEnergyDelta, secondaryEnergyDelta]

print(outputFloat2String(specific_ouputs))